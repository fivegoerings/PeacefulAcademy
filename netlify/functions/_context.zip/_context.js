var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/_context.mjs
var context_exports = {};
__export(context_exports, {
  getDatabaseUrl: () => getDatabaseUrl,
  getDeploymentContext: () => getDeploymentContext,
  getSiteUrl: () => getSiteUrl
});
module.exports = __toCommonJS(context_exports);
function getDeploymentContext() {
  if (process.env.CONTEXT)
    return process.env.CONTEXT;
  if (process.env.NETLIFY_LOCAL === "true")
    return "dev";
  return "production";
}
function getSiteUrl() {
  const context = getDeploymentContext();
  if (context === "production") {
    return process.env.URL || process.env.SITE_URL || "";
  }
  return process.env.DEPLOY_PRIME_URL || process.env.URL || process.env.SITE_URL || "";
}
function getDatabaseUrl() {
  if (process.env.NETLIFY_DATABASE_URL)
    return process.env.NETLIFY_DATABASE_URL;
  const context = getDeploymentContext();
  if (context === "dev") {
    return process.env.NETLIFY_DATABASE_URL_DEV || process.env.DATABASE_URL || "";
  }
  if (context === "deploy-preview" || context === "branch-deploy") {
    return process.env.NETLIFY_DATABASE_URL_PREVIEW || process.env.DATABASE_URL || "";
  }
  return process.env.DATABASE_URL || "";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getDatabaseUrl,
  getDeploymentContext,
  getSiteUrl
});
